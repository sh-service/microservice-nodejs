const mongoose = require('mongoose');
const Schema = mongoose.Schema , ObjectId = Schema.ObjectId;

const productlogsSchema = new Schema({
  product_id: {
    type: ObjectId,
    required: true,
    trim: true
  },
  user_id: {
    type: ObjectId,
    required: true,
    trim: true
  },
  created_date: {
    type: Date,
    default: Date.now
   }
});

module.exports = mongoose.model('Productlogs', productlogsSchema);