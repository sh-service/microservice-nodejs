const connUri = process.env.MONGO_LOCAL_CONN_URL;
const mongoose = require('mongoose');
mongoose.connect(connUri, { useNewUrlParser: true, useUnifiedTopology:true });