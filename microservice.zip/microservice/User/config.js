module.exports = {
  development: {
    port: process.env.PORT || 4000,
    saltingRounds: 10
  }
}