const connUri = process.env.MONGO_LOCAL_CONN_URL;
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const {Product,User} = require('./models');

module.exports = {
  validateToken: (req, res, next) => {
    const token = req.headers.authorization;
    
    //console.log(result); return false;
    let result;
    if (token) {
      
      try {
        let result = jwt.verify(token, process.env.JWT_SECRET);
        req.decoded = result;
        next();
      } catch (err) {
        throw new Error(err);
      }
    } else {
      result = { 
        error: `Authentication error. Token required.`,
        status: 401
      };
      res.status(401).send(result);
    }
  },
  getUser: async (name)=>{
      if(name!=""){        
        return await User.findOne({name:name},'name role').exec();        
      }
  },
  sendEmail :(email)=>{
      let mailTransporter = nodemailer.createTransport({ 
          service: 'gmail', 
          auth: { 
              user: 'test@gmail.com', 
              pass: ''
          } 
      }); 
        
      let mailDetails = { 
          from: 'test@gmail.com', 
          to: email, 
          subject: 'Staff Invitaion', 
          text: 'Welcome to micro service'
      }; 
      mailTransporter.sendMail(mailDetails, function(err, data) { 
          if(err) { 
              console.log('Error Occurs'); 
          } else { 
              console.log('Email sent successfully'); 
          } 
      }); 

  }
};
