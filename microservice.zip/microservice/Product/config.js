module.exports = {
  development: {
    port: process.env.PORT || 4001,
    saltingRounds: 10
  }
}