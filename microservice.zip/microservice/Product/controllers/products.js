const {Product,User,Productlogs} = require('../models');
const utils = require('../utils');

module.exports = {
  add: (req, res) => { 
        
        let result = {}        
        const payload = req.decoded;
        
        utils.getUser(payload.user).then((user)=>{
            var user_id = user._id;
            if (user.role == 'admin') {
              var { name,price,quantity } = req.body;
              var status = 1;

              var product = new Product({ name,price,quantity,status });
                product.save((err, product) => {
                  //console.log(err); console.log(product); return false;
                  var status = 201
                  if (!err) {
                    result.status = status;
                    result.result = product;
                    // Create Logs
                    var product_id = product._id;
                    
                    var productlogs = new Productlogs({ product_id,user_id });
                    productlogs.save((err, productlogs)=>{
                    });
                  } else { 
                    status = 500;
                    result.status = status;
                    result.error = err;
                  }
                  res.status(status).send(result);
                });

              }else{
                var { name,price,quantity } = req.body;
                var status = 0;
                var product = new Product({ name,price,quantity,status }); // Pending for approval
                product.save((err, product) => { 
                var status = 201           
                  if (!err) {
                    result.status = status;
                    result.result = product;

                    // Create Logs
                    var product_id = product._id;

                    var productlogs = new Productlogs({ product_id,user_id });
                    productlogs.save((err, productlogs)=>{
                    });

                  } else { 
                    status = 500;
                    result.status = status;
                    result.error = err;
                  }
                  console.log("Sending email to administrator");
                  //utils.sendEmail();
                  res.status(status).send(result);
                });

              }
        })
        .catch((err)=>{
          var status = 500;
          result.status = status;
          result.error = err;
          res.status(status).send(result);
        });
    
  },
  getAll: (req, res) => {
        let result = {}
        status = 200   
        const payload = req.decoded;
          
        Product.find({}, (err, products) => {
            if (!err) {
              result.status = status;
              result.error = err;
              result.result = products;
            } else {
              status = 500;
              result.status = status;
              result.error = err;
            }
            res.status(status).send(result);
          });        
      
  },


}