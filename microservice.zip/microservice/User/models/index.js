const users = require('./users');

module.exports = {
  User : users
};