const users = require('./users');
const products = require('./products');
const productlogs = require('./productlogs');

module.exports = {
  Product : products,
  User : users,
  Productlogs : productlogs
};