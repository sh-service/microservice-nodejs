const controller = require('../controllers/products');
const utils = require('../utils');

module.exports = (router) => {
  router.route('/products')
    .post(utils.validateToken,controller.add)
    .get(utils.validateToken,controller.getAll); // This route will be protected shortly
};