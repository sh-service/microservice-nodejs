const products = require('./products');

module.exports = (router) => {
  products(router);
  return router;
};